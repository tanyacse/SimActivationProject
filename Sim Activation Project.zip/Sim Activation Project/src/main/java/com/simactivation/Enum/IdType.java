package com.simactivation.Enum;

public class IdType {


}
